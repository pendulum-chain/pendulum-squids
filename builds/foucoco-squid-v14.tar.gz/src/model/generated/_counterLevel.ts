export enum CounterLevel {
    Global = 'Global',
    Pallet = 'Pallet',
    Item = 'Item',
}
