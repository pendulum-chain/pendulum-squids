export enum ItemType {
    Extrinsics = 'Extrinsics',
    Calls = 'Calls',
    Events = 'Events',
}
