import { AssetId } from './amplitude/v7'
import { CurrencyId } from './amplitude/v10'

export { AssetId, CurrencyId }
