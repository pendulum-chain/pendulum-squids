import { EventHandlerContext } from '../processor'
import {
    amplitudeStorage,
    foucocoStorage,
    pendulumStorage,
} from '../types/storage'
import { AssetId, CurrencyId } from '../types/common'
import { codec } from '@subsquid/ss58'
import { config, network } from '../config'
import { invert } from 'lodash'
import { hexToU8a } from '@polkadot/util'
export const currencyKeyMap: { [index: number]: string } = {
    0: 'Native',
    1: 'XCM',
    2: 'Stellar',
    3: 'ZenlinkLPToken',
}

export enum CurrencyTypeEnum {
    Native = 0,
    XCM = 1,
    Stellar = 2,
    ZenlinkLPToken = 3,
}

export enum CurrencyIndexEnum {
    KSM = 0,
    USDT = 1,
    XLM = 256,
}

export const currencyTokenSymbolMap: { [index: number]: string } = {
    // XCM assets
    0: 'KSM',
    1: 'USDT',

    // Stellar assets
    256: 'XLM',
}

export const invertedTokenSymbolMap = invert(currencyTokenSymbolMap)

export function addressFromAsset({ chainId, assetIndex, assetType }: AssetId) {
    return `${chainId}-${assetType}-${assetIndex.toString()}`
}

export function assetIdFromAddress(address: string): AssetId {
    const [chainId, assetType, assetIndex] = address.split('-')
    return {
        chainId: Number(chainId),
        assetType: Number(assetType),
        assetIndex: BigInt(assetIndex),
    }
}

export function parseTokenType(assetIndex: number): string {
    const assetU8 = (assetIndex & 0x0000_0000_0000_ff00) >> 8

    return currencyKeyMap[assetU8]
}

export const USDT_ISSUER: Uint8Array = new Uint8Array([
    59, 153, 17, 56, 14, 254, 152, 139, 160, 168, 144, 14, 177, 207, 228, 79,
    54, 111, 125, 190, 148, 107, 237, 7, 114, 64, 247, 246, 36, 223, 21, 197,
])

export const BRL_ISSUER: Uint8Array = new Uint8Array([
    234, 172, 104, 212, 208, 227, 123, 76, 36, 194, 83, 105, 22, 232, 48, 115,
    95, 3, 45, 13, 107, 42, 28, 143, 202, 59, 197, 162, 94, 8, 62, 58,
])

export const TZS_ISSUER: Uint8Array = new Uint8Array([
    52, 201, 75, 42, 75, 169, 232, 181, 123, 34, 84, 125, 203, 179, 15, 68, 60,
    76, 176, 45, 163, 130, 154, 137, 170, 27, 212, 120, 14, 68, 102, 186,
])

export const USDC_CODE: Uint8Array = new Uint8Array([85, 83, 68, 67])

export const TZS_CODE: Uint8Array = new Uint8Array([84, 90, 83, 0])

export const BRL_CODE: Uint8Array = new Uint8Array([66, 82, 76, 0])

function uint8ArrToHex(uintArray: Uint8Array): string {
    let buffer = Buffer.from(uintArray)
    return '0x' + buffer.toString('hex')
}

export function zenlinkAssetIdToCurrencyId(asset: AssetId): any {
    const assetIndex = Number(asset.assetIndex.toString())
    const tokenType = parseTokenType(assetIndex) as
        | 'ZenlinkLPToken'
        | 'Stellar'
        | 'XCM'
        | 'Native'
    const assetSymbolIndex = assetIndex & 0x0000_0000_0000_00ff

    if (tokenType == 'Native') {
        return { __kind: 'Native' }
    } else if (tokenType == 'XCM') {
        return {
            __kind: tokenType,
            value: assetSymbolIndex,
        }
    } else if (tokenType == 'ZenlinkLPToken') {
        let token0Id = assetIndex & (0x0000_0000_00ff_0000 >> 16)
        let token0Type = assetIndex & (0x0000_0000_ff00_0000 >> 24)
        let token1Id = assetIndex & (0x0000_00ff_0000_0000 >> 32)
        let token1Type = assetIndex & (0x0000_ff00_0000_0000 >> 40)
        return {
            __kind: tokenType,
            value: [token0Id, token0Type, token1Id, token1Type],
        }
    } else if (tokenType == 'Stellar') {
        switch (assetSymbolIndex) {
            case 0:
                return {
                    __kind: tokenType,
                    value: {
                        __kind: 'StellarNative',
                    },
                }
            case 1:
                return {
                    __kind: tokenType,
                    value: {
                        __kind: 'AlphaNum4',
                        code: uint8ArrToHex(USDC_CODE),
                        issuer: uint8ArrToHex(USDT_ISSUER),
                    },
                }
            case 2:
                return {
                    __kind: tokenType,
                    value: {
                        __kind: 'AlphaNum4',
                        code: uint8ArrToHex(TZS_CODE),
                        issuer: uint8ArrToHex(TZS_ISSUER),
                    },
                }
            case 3:
                return {
                    __kind: tokenType,
                    value: {
                        __kind: 'AlphaNum4',
                        code: uint8ArrToHex(BRL_CODE),
                        issuer: uint8ArrToHex(BRL_ISSUER),
                    },
                }
        }
    }
}

// Adheres to derivations defined in [this](https://github.com/pendulum-chain/pendulum/blob/6f92a8d695a7a5ea23c769f03d5f3a621334094e/runtime/common/src/zenlink.rs#L63) function
export function currencyIdToAssetIndex(currency: CurrencyId): number {
    const tokenType = CurrencyTypeEnum[currency.__kind]
    let tokenIndex = 0

    switch (currency.__kind) {
        case 'Native':
            tokenIndex = 0
            break
        case 'XCM':
            tokenIndex = currency.value
            break
        case 'Stellar':
            switch (currency.value.__kind) {
                case 'StellarNative':
                    tokenIndex = 0
                    break
                case 'AlphaNum4':
                    switch (u8a2s(hexToU8a(currency.value.code))) {
                        case 'USDC':
                            tokenIndex = 1
                            break
                        case 'TZS':
                            tokenIndex = 2
                            break
                        case 'BRL':
                            tokenIndex = 3
                            break
                    }
            }
            break
        case 'ZenlinkLPToken':
            tokenIndex =
                (currency.value[0] << 16) +
                (currency.value[1] << 24) +
                (currency.value[2] << 32) +
                (currency.value[3] << 40)
            break
    }

    return parseToTokenIndex(tokenType, tokenIndex)
}

export function u8a2s(u8a: Uint8Array) {
    let dataString = ''
    for (let i = 0; i < u8a.length; i++) {
        dataString += String.fromCharCode(u8a[i])
    }

    return dataString
}

export function s2u8a(str: string) {
    const arr = []
    for (let i = 0, j = str.length; i < j; ++i) {
        arr.push(str.charCodeAt(i))
    }

    return new Uint8Array(arr)
}

export function parseToTokenIndex(type: number, index: number): number {
    if (type === 0) return 0

    return (type << 8) + index
}

const pairAssetIds = new Map<string, AssetId>()

export async function getPairAssetIdFromAssets(
    ctx: EventHandlerContext,
    assets: [AssetId, AssetId]
) {
    const [asset0, asset1] = assets
    const token0Address = addressFromAsset(asset0)
    const token1Address = addressFromAsset(asset1)
    const assetsId = `${token0Address}-${token1Address}`
    let pairAssetId: AssetId | undefined
    if (pairAssetIds.has(assetsId)) {
        pairAssetId = pairAssetIds.get(assetsId)
    } else {
        const versionPairStorage = (() => {
            let versionStorage
            if (network === 'foucoco') {
                versionStorage =
                    foucocoStorage.zenlinkProtocol.liquidityPairs.v1
            } else if (network === 'pendulum') {
                versionStorage =
                    pendulumStorage.zenlinkProtocol.liquidityPairs.v3
            } else {
                versionStorage =
                    amplitudeStorage.zenlinkProtocol.liquidityPairs.v7
            }
            return versionStorage
        })()
        if (!versionPairStorage.is) return undefined
        pairAssetId = await versionPairStorage.get(ctx.block, assets)
        if (pairAssetId) {
            pairAssetIds.set(assetsId, pairAssetId)
        }
    }
    return pairAssetId
}

const pairAccounts = new Map<string, string>()

export async function getPairStatusFromAssets(
    ctx: EventHandlerContext,
    assets: [AssetId, AssetId],
    onlyAccount = true
): Promise<[string | undefined, BigInt]> {
    const [asset0, asset1] = assets
    const token0Address = addressFromAsset(asset0)
    const token1Address = addressFromAsset(asset1)
    const assetsId = `${token0Address}-${token1Address}`
    let pairAccount: string | undefined
    if (pairAccounts.has(assetsId) && onlyAccount) {
        pairAccount = pairAccounts.get(assetsId)
        return [pairAccount!, BigInt(0)]
    } else {
        const versionStorage = (() => {
            let versionStorage
            if (network === 'foucoco') {
                versionStorage = foucocoStorage.zenlinkProtocol.pairStatuses.v1
            } else if (network === 'pendulum') {
                versionStorage = pendulumStorage.zenlinkProtocol.pairStatuses.v3
            } else {
                versionStorage =
                    amplitudeStorage.zenlinkProtocol.pairStatuses.v7
            }
            return versionStorage
        })()

        if (!versionStorage.is) return [undefined, BigInt(0)]
        const result = await versionStorage.get(ctx.block, assets)

        if (!result) return [undefined, BigInt(0)]

        if (result.__kind === 'Trading') {
            pairAccount = codec(config.prefix).encode(result.value.pairAccount)
            pairAccounts.set(assetsId, pairAccount)
            return [pairAccount, result.value.totalSupply]
        }

        return [undefined, BigInt(0)]
    }
}

export async function getTokenBalance(
    ctx: EventHandlerContext,
    assetId: CurrencyId,
    account: string
) {
    let result
    if (assetId.__kind === 'Native') {
        const systemAccountStorage = (() => {
            if (network === 'foucoco') {
                return foucocoStorage.system.account.v1
            } else if (network === 'pendulum') {
                return pendulumStorage.system.account.v1
            } else {
                return amplitudeStorage.system.account.v1
            }
        })()
        result = (await systemAccountStorage.get(ctx.block, account))?.data
    } else {
        if (network === 'foucoco') {
            result = await foucocoStorage.tokens.accounts.v1.get(
                ctx.block,
                account,
                assetId as any
            )
        } else if (network === 'pendulum') {
            if (pendulumStorage.tokens.accounts.v1.is(ctx.block)) {
                result = await pendulumStorage.tokens.accounts.v1.get(
                    ctx.block,
                    account,
                    assetId as any
                )
            }
            if (pendulumStorage.tokens.accounts.v3.is(ctx.block)) {
                result = await pendulumStorage.tokens.accounts.v3.get(
                    ctx.block,
                    account,
                    assetId as any
                )
            }
        } else {
            if (amplitudeStorage.tokens.accounts.v3.is(ctx.block)) {
                result = await amplitudeStorage.tokens.accounts.v3.get(
                    ctx.block,
                    account,
                    assetId as any
                )
            }
            if (amplitudeStorage.tokens.accounts.v8.is(ctx.block)) {
                result = await amplitudeStorage.tokens.accounts.v8.get(
                    ctx.block,
                    account,
                    assetId as any
                )
            }
            if (amplitudeStorage.tokens.accounts.v10.is(ctx.block)) {
                result = await amplitudeStorage.tokens.accounts.v10.get(
                    ctx.block,
                    account,
                    assetId as any
                )
            }
        }
    }

    return result?.free
}

export async function getTotalIssuance(
    ctx: EventHandlerContext,
    assetId: CurrencyId
) {
    let result
    if (assetId.__kind === 'Native') {
        const balanceIssuanceStorage = (() => {
            if (network === 'foucoco') {
                return foucocoStorage.balances.totalIssuance.v1
            } else if (network === 'pendulum') {
                return pendulumStorage.balances.totalIssuance.v1
            } else {
                return amplitudeStorage.balances.totalIssuance.v1
            }
        })()
        result = await balanceIssuanceStorage.get(ctx.block)
    } else {
        if (network === 'foucoco') {
            result = await foucocoStorage.tokens.totalIssuance.v1.get(
                ctx.block,
                assetId as any
            )
        } else if (network === 'pendulum') {
            if (pendulumStorage.tokens.totalIssuance.v1.is(ctx.block)) {
                result = await pendulumStorage.tokens.totalIssuance.v3.get(
                    ctx.block,
                    assetId as any
                )
            }
            if (pendulumStorage.tokens.totalIssuance.v3.is(ctx.block)) {
                result = await pendulumStorage.tokens.totalIssuance.v3.get(
                    ctx.block,
                    assetId as any
                )
            }
        } else {
            if (amplitudeStorage.tokens.totalIssuance.v3.is(ctx.block)) {
                result = await amplitudeStorage.tokens.totalIssuance.v3.get(
                    ctx.block,
                    assetId as any
                )
            }
            if (amplitudeStorage.tokens.totalIssuance.v8.is(ctx.block)) {
                result = await amplitudeStorage.tokens.totalIssuance.v8.get(
                    ctx.block,
                    assetId as any
                )
            }
            if (amplitudeStorage.tokens.totalIssuance.v10.is(ctx.block)) {
                result = await amplitudeStorage.tokens.totalIssuance.v10.get(
                    ctx.block,
                    assetId as any
                )
            }
        }
    }

    return result
}

export async function getTokenBurned(
    ctx: EventHandlerContext,
    assetId: CurrencyId,
    account: string
) {
    let block = {
        hash: ctx.block.parentHash,
    }
    let result
    if (assetId.__kind === 'Native') {
        const systemAccountStorage = (() => {
            if (network === 'foucoco') {
                return foucocoStorage.system.account.v1
            } else if (network === 'pendulum') {
                return pendulumStorage.system.account.v1
            } else {
                return amplitudeStorage.system.account.v1
            }
        })()
        result = (await systemAccountStorage.get(ctx.block, account))!.data
    } else {
        if (network === 'foucoco') {
            result = await foucocoStorage.tokens.accounts.v1.get(
                ctx.block,
                account,
                assetId as any
            )
        } else if (network === 'pendulum') {
            if (pendulumStorage.tokens.accounts.v1.is(ctx.block)) {
                result = await pendulumStorage.tokens.accounts.v1.get(
                    ctx.block,
                    account,
                    assetId as any
                )
            }
            if (pendulumStorage.tokens.accounts.v3.is(ctx.block)) {
                result = await pendulumStorage.tokens.accounts.v3.get(
                    ctx.block,
                    account,
                    assetId as any
                )
            }
        } else {
            if (amplitudeStorage.tokens.accounts.v3.is(ctx.block)) {
                result = await amplitudeStorage.tokens.accounts.v3.get(
                    ctx.block,
                    account,
                    assetId as any
                )
            }
            if (amplitudeStorage.tokens.accounts.v8.is(ctx.block)) {
                result = await amplitudeStorage.tokens.accounts.v8.get(
                    ctx.block,
                    account,
                    assetId as any
                )
            }
            if (amplitudeStorage.tokens.accounts.v10.is(ctx.block)) {
                result = await amplitudeStorage.tokens.accounts.v10.get(
                    ctx.block,
                    account,
                    assetId as any
                )
            }
        }
    }

    return result?.free
}
